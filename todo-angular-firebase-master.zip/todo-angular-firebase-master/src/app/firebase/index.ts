import * as firebase from 'firebase/app';

export { firebase };
export { FirebaseModule } from './firebase.module';
