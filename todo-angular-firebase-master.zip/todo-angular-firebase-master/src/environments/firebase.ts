export const firebaseConfig = {
  apiKey: 'AIzaSyDaEW83qAOozjJbbJP1YYbEHxxfFksdSHQ',
  authDomain: 'ng2-todo-app.firebaseapp.com',
  databaseURL: 'https://ng2-todo-app.firebaseio.com',
  storageBucket: 'ng2-todo-app.appspot.com'
};
