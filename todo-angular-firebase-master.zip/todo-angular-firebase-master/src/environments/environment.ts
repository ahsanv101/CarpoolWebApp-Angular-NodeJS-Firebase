import { firebaseConfig } from './firebase';


export const environment = {
  production: false,
  firebase: firebaseConfig
};
