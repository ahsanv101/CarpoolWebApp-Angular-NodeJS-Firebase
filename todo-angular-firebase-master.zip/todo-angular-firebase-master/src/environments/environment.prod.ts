import { firebaseConfig } from './firebase';


export const environment = {
  production: true,
  firebase: firebaseConfig
};
